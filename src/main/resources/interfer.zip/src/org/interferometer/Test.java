package org.interferometer;

import org.interferometer.difference.Difference2Info;
import org.interferometer.difference.RestoredTableFunction;
import org.interferometer.difference.RestoredTableFunction2;
import org.interferometer.difference.Shift1Function2;
import org.interferometer.difference.Shift2Function2;
import org.interferometer.difference.ShiftFunction;
import org.interferometer.difference.DifferenceInfo;
import org.interferometer.function.AbstractFunction1;
import org.interferometer.function.AbstractFunction2;
import org.interferometer.function.TableFunction;
import org.interferometer.function.TableFunction2;
import org.ojalgo.matrix.BasicMatrix;
import org.ojalgo.optimisation.Expression;
import org.ojalgo.optimisation.ExpressionsBasedModel;
import org.ojalgo.optimisation.OptimisationSolver;
import org.ojalgo.optimisation.OptimisationSolver.Result;
import org.ojalgo.optimisation.Variable;
import org.ojalgo.optimisation.quadratic.QuadraticExpressionsModel;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.math.BigDecimal;

public class Test
{
	static void testSolver() 		// проверка, как работает квадратичное программирование
	{
		int n = 2; // количество переменных
		int m = 2; // количество ограничений
		Variable vars[] = new Variable[n];
		for(int i=0; i<n; ++i) // имена x1, x2, ... xn
			vars[i] = Variable.make(String.format("x%d", i+1));
		ExpressionsBasedModel<?> model = new QuadraticExpressionsModel(vars);
		for(int j=0; j<m; ++j) // добавляем линейные ограничения
		{
			Expression ex = model.addEmptyLinearExpression(String.format("%d", j+1));
			for(int i=0; i<n; ++i)
			{
				double aij = (i==j? 1:0); // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
				ex.setLinearFactor(i, new BigDecimal(aij));
			}
			double bj = 0; // !!!!!!!!!!!!!!!!!!!!!!!!!
			// ограничения сверху и снизу:
			ex.setLowerLimit(new BigDecimal(bj));
			ex.setUpperLimit(new BigDecimal(bj+1));
		}
		Expression objex = model.addEmptyCompoundExpression("y");
		objex.setContributionWeight(new BigDecimal(1)); // 1 - минимизация, -1 - максимизация!
		// Добавляем квадратичную часть целевой функции.
		// Если минимизируем, матрица должна быть неотрицательно определённой. 
		// Если максимизируем - неположительно. Иначе работать не будет!
		for(int i=0; i<n; ++i)
			for(int j=0; j<n; ++j)
			{
				double qij = (i==j? 1:0); // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
				objex.setQuadraticFactor(i, j, new BigDecimal(qij));
			}
		// Добавляем линейную часть целевой функции:
		for(int i=0; i<n; ++i)
		{
			double ci = -4+i; // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
			objex.setLinearFactor(i, new BigDecimal(ci));
		}
		// Решаем задачу:
		OptimisationSolver solver = model.getDefaultSolver();
		// Если только равенства - работает LagrangeSolver. Он сводит решение к системе линейных уравнений
		// и вызывает EquationSystemSolver (решение в 1 шаг).
		// Если есть неравенства - ActiveSetSolver. Он на каждом шаге устанавливает активные неравенства
		// и использует LagrangeSolver, в котором активные неравенства заменяются на равенства, а остальные откидываются.
		System.out.printf("Matrices: \n%s", solver.toString());		
		Result result = solver.solve();
		BasicMatrix vector = result.getSolution();
		switch(result.getState())
		{
		// Глюка:
		case NEW: System.out.printf("New!\n");
		case FAILED: System.out.printf("Failed!\n");
					break;
		// Решений нет:
		case ITERATION:  System.out.printf("Iteration!\n");
		case INFEASIBLE: System.out.printf("Infeasible!\n");
					break;
		// Задача неограничена:
		case UNBOUNDED: System.out.printf("Unbounded!\n");
					break;
		// Решение найдено:
		case UNIQUE: System.out.printf("Unique!\n");
		case OPTIMAL: System.out.printf("Optimal!\n");
		case FEASIBLE: System.out.printf("Feasible!\n");
		// Выводим его на экран:
					for(int i=0; i<vector.getRowDim(); ++i)
						System.out.printf("x%d = %f\n", i+1, vector.toBigDecimal(i, 0).doubleValue());
					break;
		}
	}
	
	static void testRestore1() // проверка восстановления 1-мерной функции по разности
	{
		  // создаём табличную функцию из значений в input.txt
		TableFunction fun = new TableFunction(0, 100, 100);
		double s = 10;
		try
		{
		  FileInputStream fin = new FileInputStream("input.txt");
		  fun.read( new DataInputStream(fin) );
		
		// создаём разностную функцию
		  AbstractFunction1 deltaf = new ShiftFunction(fun, s);
		  DifferenceInfo diff = new DifferenceInfo(deltaf, s);
		  
		// на всякий случай её записываем:
		  TableFunction tabledeltaf = new TableFunction(10, 99, 89);
		  tabledeltaf.assign(deltaf);
		  FileOutputStream fdeltaout = new FileOutputStream("outputd.txt");
		  tabledeltaf.write( new DataOutputStream(fdeltaout) );
		
		// восстанавливаем исходную функцию по разностной
		  final double hl = 1;
		  final double halpha = 0.5; 
		  AbstractFunction1 helder = new AbstractFunction1() // предполагаем, что функция удовлетворяет условию Гёльдера с такими константами
		  {
			  public double invoke(double x)
			  {
				return hl*Math.pow(x, halpha);
			  }
		  };
		
		  RestoredTableFunction fun2 = new RestoredTableFunction(0, 100, 100, helder);
		  fun2.restoreByShift(diff);
		  System.out.printf("Function is restored!");
		// записываем восстановленную функцию в output.txt - должно получиться близко к исходной функции
		  FileOutputStream fout = new FileOutputStream("output.txt");
		  fun2.write( new DataOutputStream(fout) );
		 }
		 catch(FileNotFoundException ex)
		 {
		  ex.printStackTrace();
		 }	
	}
	
	static void testRestore2(int size1, int size2, int s, double h) // проверка восстановления 2-мерной функции по разности
	{
		  // создаём табличную функцию из значений в input.txt
		TableFunction2 fun = new TableFunction2(0, size1, 0, size2, size1, size2);
		try
		{
		  FileInputStream fin = new FileInputStream("input.txt");
		  fun.read( new DataInputStream(fin) );
		
		// создаём разностные функции
		  AbstractFunction2 delta1f = new Shift1Function2(fun, s);
		  AbstractFunction2 delta2f = new Shift2Function2(fun, s);
		  Difference2Info diff = new Difference2Info(delta1f, delta2f, s);
		// на всякий случай их записываем:
		  TableFunction2 tabledeltaf = new TableFunction2(s, size1-1, s, size2-1, size1-s-1, size2-s-1);
		  tabledeltaf.assign(delta1f);
		  FileOutputStream fdelta1out = new FileOutputStream("outputd1.txt");
		  tabledeltaf.write( new DataOutputStream(fdelta1out) );
		  tabledeltaf.assign(delta2f);
		  FileOutputStream fdelta2out = new FileOutputStream("outputd2.txt");
		  tabledeltaf.write( new DataOutputStream(fdelta2out) );
		
		// восстанавливаем исходную функцию по разностной
		  final double hl = 1;
		  final double halpha = 0.5; 
		  AbstractFunction1 helder = new AbstractFunction1() // предполагаем, что функция удовлетворяет условию Гёльдера с такими константами
		  {
			  public double invoke(double x)
			  {
				return hl*Math.pow(x, halpha);
			  }
		  };
		
		  RestoredTableFunction2 fun2 = new RestoredTableFunction2(0, size1, 0, size2, size1, size2, helder, h);
		  fun2.restoreByShift(diff);
		  System.out.printf("Function is restored!");
		// записываем восстановленную функцию в output.txt - должно получиться близко к исходной функции
		  FileOutputStream fout = new FileOutputStream("output.txt");
		  fun2.write( new DataOutputStream(fout) );
		 }
		 catch(FileNotFoundException ex)
		 {
		  ex.printStackTrace();
		 }	
	}

	
  public static void main(String args[])
  {
	  // testSolver();
	 // testRestore1();
	  testRestore2(13, 16, 3, 1);
  }
}
