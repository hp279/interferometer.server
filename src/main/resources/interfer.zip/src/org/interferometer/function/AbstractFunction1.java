package org.interferometer.function;

import org.ojalgo.function.UnaryFunction;

public abstract class AbstractFunction1 extends AbstractFunction implements UnaryFunction<Double>
{	
	  public Double invoke(Double x)
	  {
		  return this.invoke(x.doubleValue());
	  }
	
	  public double diff(double x, double h)
	  {
		  return (invoke(x+h) - invoke(x-h))/(2*h);
	  }
  
	  public double diff2(double x, double h)
	  {
		  return (invoke(x+h) - 2*invoke(x) + invoke(x-h))/(h*h);
	  }
}